export const TwelveData = [
    {
        id: 1,
        size: 30,
    },
    {
        id: 2,
        size: 30,
    },
    {
        id: 3,
        size: 30,
    },
    {
        id: 4,
        size: 30,
    },
    {
        id: 5,
        size: 30,
    },
    {
        id: 6,
        size: 30,
    },
    {
        id: 7,
        size: 30,
    },
    {
        id: 8,
        size: 30,
    },
    {
        id: 9,
        size: 30,
    },
    {
        id: 10,
        size: 30,
    },
    {
        id: 11,
        size: 30,
    },
    {
        id: 12,
        size: 30,
    },
]