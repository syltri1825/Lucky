export const TenData = [
    {
        id: 1,
        size: 36,
    },
    {
        id: 2,
        size: 36,
    },
    {
        id: 3,
        size: 36,
    },
    {
        id: 4,
        size: 36,
    },
    {
        id: 5,
        size: 36,
    },
    {
        id: 6,
        size: 36,
    },
    {
        id: 7,
        size: 36,
    },
    {
        id: 8,
        size: 36,
    },
    {
        id: 9,
        size: 36,
    },
    {
        id: 10,
        size: 36,
    },
]