export const FifteenData = [

    {
        id: 1,
        size: 24,
    },
    {
        id: 2,
        size: 24,
    },
    {
        id: 3,
        size: 24,
    },
    {
        id: 4,
        size: 24,
    },
    {
        id: 5,
        size: 24,
    },
    {
        id: 6,
        size: 24,
    },
    {
        id: 7,
        size: 24,
    },
    {
        id: 8,
        size: 24,
    },
    {
        id: 9,
        size: 24,
    },
    {
        id: 10,
        size: 24,
    },
    {
        id: 11,
        size: 24,
    },
    {
        id: 12,
        size: 24,
    },
    {
        id: 13,
        size: 24,
    },
    {
        id: 14,
        size: 24,
    },
    {
        id: 15,
        size: 24,
    },
]