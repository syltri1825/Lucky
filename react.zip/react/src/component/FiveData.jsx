export const FiveData = [
    {
        id: 1,
        size: 72,
    },
    {
        id: 2,
        size: 72,
    },
    {
        id: 3,
        size: 72,
    },
    {
        id: 4,
        size: 72,
    },
    {
        id: 5,
        size: 72,
    },
    
]